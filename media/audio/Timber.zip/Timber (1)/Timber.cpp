#include <SFML/Graphics.hpp>
#include <SFML/Graphics/RenderWindow.hpp>
#include <SFML/Graphics/Sprite.hpp>
#include <SFML/Graphics/Texture.hpp>
#include <SFML/System/Time.hpp>
#include <SFML/System/Vector2.hpp>
#include <SFML/Window/Keyboard.hpp>
#include <SFML/Window/VideoMode.hpp>
#include <SFML/Window/Window.hpp>
#include <cstdlib>
#include <ctime>
using namespace sf;
int main()
{
    int playerScore = 0;
    char playerInitial = 'J';
    const float PI = 3.141f;
    bool isAlive = true;

    VideoMode vm(1360, 768);
    RenderWindow window(vm, "Timber!!!", Style::Fullscreen);
    Texture textureBackground;
    textureBackground.loadFromFile("graphics/background.png");
    Sprite spriteBackground;
    spriteBackground.setTexture(textureBackground);

    Vector2f scaleFactor((1360.0) / 1920, (768.0) / 1080 );
    spriteBackground.setScale(scaleFactor.x, scaleFactor.y);

    spriteBackground.setPosition(0,0);
    Texture textureTree;
    textureTree.loadFromFile("graphics/tree.png");
    Sprite spriteTree;
    spriteTree.setTexture(textureTree);
    Vector2f treePos(810, 0);
    spriteTree.setPosition(treePos.x * scaleFactor.x, treePos.y * scaleFactor.y);
    spriteTree.setScale(scaleFactor.x, scaleFactor.y);
    Texture textureBee;
    textureBee.loadFromFile("graphics/bee.png");
    Sprite spriteBee;
    spriteBee.setTexture(textureBee);
    Vector2f beePos(0, 800);
    spriteBee.setPosition(beePos.x *scaleFactor.x, beePos.y *scaleFactor.y);
    spriteBee.setScale(scaleFactor.x, scaleFactor.y);
    bool beeActive = false;
    float beeSpeed = 0.0f;
    Texture textureCloud;
    textureCloud.loadFromFile("graphics/cloud.png");
    Sprite spriteCloud1;
    Sprite spriteCloud2;
    Sprite spriteCloud3;
    spriteCloud1.setTexture(textureCloud);
    spriteCloud2.setTexture(textureCloud);
    spriteCloud3.setTexture(textureCloud);
    Vector2f cloudPos1(0,0);
    Vector2f cloudPos2(0,150);
    Vector2f cloudPos3(0,300);
    spriteCloud1.setPosition(cloudPos1.x*scaleFactor.x,cloudPos1.y*scaleFactor.y);
    spriteCloud2.setPosition(cloudPos2.x*scaleFactor.x,cloudPos2.y*scaleFactor.y);
    spriteCloud3.setPosition(cloudPos3.x*scaleFactor.x,cloudPos3.y*scaleFactor.y);
    spriteCloud1.setScale(scaleFactor.x,scaleFactor.y);
    spriteCloud2.setScale(scaleFactor.x,scaleFactor.y);
    spriteCloud3.setScale(scaleFactor.x,scaleFactor.y);
    bool cloud1Active=false;
    bool cloud2Active=false;
    bool cloud3Active=false;
    float cloud1Speed=0.0f;
    float cloud2Speed=0.0f;
    float cloud3Speed=0.0f;
    Clock clock;
    bool paused=true;
    while (window.isOpen())
    {
        /**pLAYER Input*/

        if (Keyboard::isKeyPressed(Keyboard::Escape))
        {
            window.close();
        }
        if (Keyboard::isKeyPressed(Keyboard::Enter))
        {
            paused=false;
        }
        if (!paused)
        {

        /*Update scene*/
        Time dt=clock.restart();
        if (!beeActive)
        {
            srand((int) time(0));
            beeSpeed=((rand() % 200) +200)*scaleFactor.x;
            srand((int)time(0)*10);
            float height=(rand()%500+500)*scaleFactor.y;
            spriteBee.setPosition(2000*scaleFactor.x, height);
            beeActive=true;

        }
        else
        {
            spriteBee.setPosition(
                spriteBee.getPosition().x -
                (beeSpeed *dt.asSeconds()),
                spriteBee.getPosition().y);
            if (spriteBee.getPosition().x < -100)
            {
                beeActive = false;
            }
        }
        if (!cloud1Active)
        {
            srand((int)time(0)*10);
            cloud1Speed=((rand()%200)*scaleFactor.x);
            srand((int)time(0)*10);
            float height=((rand()%150)*scaleFactor.y);
            spriteCloud1.setPosition(-200*scaleFactor.x,height);
            cloud1Active=true;

        }
        else
        {
            spriteCloud1.setPosition(
                spriteCloud1.getPosition().x +
                (cloud1Speed*dt.asSeconds()),
                spriteCloud1.getPosition().y);
                if (spriteCloud1.getPosition().x>1920*scaleFactor.x)
                {
                    cloud1Active=false;
                }
        if (!cloud2Active)
        {
            srand((int)time(0)*20);
            cloud2Speed=((rand()%200)*scaleFactor.x);
            srand((int)time(0)*20);
            float height=(((rand()%300)-150)*scaleFactor.y);
            spriteCloud2.setPosition(-200*scaleFactor.x,height);
            cloud2Active=true;

        }
        else
        {
            spriteCloud2.setPosition(
                spriteCloud2.getPosition().x+
                (cloud2Speed*dt.asSeconds()),
                spriteCloud2.getPosition().y);
            if (spriteCloud2.getPosition().x>1920*scaleFactor.x)
            {
                cloud2Active=false;
            }
            if (!cloud3Active)
            {
                srand((int)time(0)*30);
                cloud3Speed=((rand()%200)*scaleFactor.x);
                srand((int)time(0)*30);
                float height=((rand()%450)-150)*scaleFactor.y;
                spriteCloud3.setPosition(-200*scaleFactor.x,height);
                cloud3Active=true;
            }
            else
            {
                spriteCloud3.setPosition(
                    spriteCloud3.getPosition().x+
                    (cloud3Speed*dt.asSeconds()),
                    spriteCloud3.getPosition().y);
                    if (spriteCloud3.getPosition().x>1920*scaleFactor.x)
                    {
                        cloud3Active=false;
                    }

            }
        }
        }
    }
        window.clear();
        window.draw(spriteBackground);
        window.draw(spriteCloud1);
        window.draw(spriteCloud2);
        window.draw(spriteCloud3);
        window.draw(spriteTree);
        window.draw(spriteBee);
        window.display();
    }
    return 0;
}
